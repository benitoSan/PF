--ex1
dobro::Int -> Int
dobro n = 2*n

quad::Int -> Int
quad n = dobro (dobro n)

descobre_hipotenusa::Float -> Float -> Float
descobre_hipotenusa x y = sqrt(x**2 + y**2)

dist_pontos::Float -> Float -> Float
dist_pontos a b = abs(a - b)

--ex3
-- 1 real = 3,96 dólares = 4,45 euros
conversao::Float -> (Float, Float, Float)
conversao r = (r, r*3.96, r*4.45)

--ex4
bissexto::Int -> Bool
bissexto a
    | mod a 400 == 0 = True
    | mod a 4 == 0 && mod a 100 /= 0 = True
    | otherwise = False

--ex5
type Data = (Int, Int, Int)

bissexto2::Data -> Bool
bissexto2 (d, m, a)
    | mod a 400 == 0 = True
    | mod a 4 == 0 && mod a 100 /= 0 = True
    | otherwise = False

--ex6
-- Usa o Data do exercicio anterior
valida::Data -> Bool
valida (d, m, a)
    | d >= 1 && d <= 31 && (m == 1 || m == 3 || m == 5 || 
                           m == 7 || m == 8 || m == 10 || m == 12) = True
    | d >= 1 && d <= 30 && (m == 4 || m == 6 ||
                            m == 9 || m == 11) = True
    | d >= 1 && d <= 28 && m == 2 && not (bissexto a) = True
    | d >= 1 && d <= 29 && m == 2 && bissexto a = True
    | otherwise = False

--ex7
precede::Data -> Data -> Bool
precede (d1, m1, a1) (d2, m2, a2)
    | (a1, m1, d1) < (a2, m2, d2) = True
    | otherwise = False

--ex8
-- Usa o Data do exercicio 4
type Livro = (String, String, String, String, Int)
type Aluno = (String, String, String, String)
type Emprestimo = (String, String, Data, Data, String)
--Livro: (código do livro, título do livro, autor, editora e ano de publicação)
--Aluno: (código do aluno, nome, e-mail e telefone)
--Emprestimo: código do livro, código do aluno, data de empréstimo, data de devolução e situação

--ex9
-- Usa o Data do exercicio 4
verifica_emprestimo::Emprestimo -> Data -> Bool
verifica_emprestimo (cod_livro, cod_aluno, (d_emp, m_emp, a_emp), (d_dev, m_dev, a_dev), situacao) (d, m, a)
    | precede (d, m, a) (d_dev, m_dev, a_dev) = True
    | otherwise = False

e1::Emprestimo
e1 = ("H123C9","BSI200945",(12,9,2009),(20,9,2009),"aberto")