-- ex1
-- a)
-- perguntar se type data tem que esta dentro do where
type Data = (Int, Int, Int)
valida::Data -> Bool
valida (d, m, a)
    | d >= 1 && d <= 31 && (m == 1 || m == 3 || m == 5 || 
                           m == 7 || m == 8 || m == 10 || m == 12) = True
    | d >= 1 && d <= 30 && (m == 4 || m == 6 ||
                            m == 9 || m == 11) = True
    | d >= 1 && d <= 28 && m == 2 && not (bissexto a) = True
    | d >= 1 && d <= 29 && m == 2 && bissexto a = True
    | otherwise = False
        where
            bissexto::Int -> Bool
            bissexto a
                | mod a 400 == 0 = True
                | mod a 4 == 0 && mod a 100 /= 0 = True
                | otherwise = False


-- b)
bissextos::[Int] -> [Int]
bissextos xs = [x | x <- xs, bissexto x]
    where
        bissexto::Int -> Bool
        bissexto a
            | mod a 400 == 0 = True
            | mod a 4 == 0 && mod a 100 /= 0 = True
            | otherwise = False


-- c)
-- verificar se esta certo
-- type Data = (Int, Int, Int)
type Emprestimo = (String, String, Data, Data, String)
type Emprestimos = [Emprestimo]

bdEmprestimo::Emprestimos
bdEmprestimo =
 [("H123C9","BSI945",(12,9,2009),(20,09,2009),"aberto"),
 ("L433C5","BCC021",(01,9,2009),(10,09,2009),"encerrado"),
 ("M654C3","BCC008",(04,9,2009),(15,09,2009),"aberto")]

atrasados:: Emprestimos -> Data -> Emprestimos
atrasados empretimos_livros d = [x | x <- empretimos_livros, not (verifica_emprestimo x d)]
    where
        verifica_emprestimo::Emprestimo -> Data -> Bool
        verifica_emprestimo (cod_livro, cod_aluno, (d_emp, m_emp, a_emp), (d_dev, m_dev, a_dev), situacao) (d, m, a)
            | precede (d, m, a) (d_dev, m_dev, a_dev) = True
            | otherwise = False

        precede::Data -> Data -> Bool
        precede (d1, m1, a1) (d2, m2, a2)
            | (a1, m1, d1) < (a2, m2, d2) = True
            | otherwise = False


-- d)
fibo2::Int->Int
fibo2 n = fst (fiboAux n)
    where
        passo::(Int,Int)->(Int,Int)
        passo (x,y)
            | x == 0 && y == 0 = (1,1)
            | otherwise = (y, x+y)

        fiboAux::Int->(Int,Int)
        fiboAux n
            | n == 1 = passo(0,0)
            | otherwise = passo(fiboAux (n-1))


-- e)
fat::Int->Int
fat n = prodIntervalo 1 n
    where
        prodIntervalo::Int->Int->Int
        prodIntervalo m n
            | m > n = 1
            | m == n = m
            | otherwise = m*(prodIntervalo (m+1)(n-1))*n



-- ex2
-- a)
-- perguntar se type data tem que esta dentro do where
-- perguntar como colocar let in com funcoes apenas de guardas
-- type Data = (Int, Int, Int)
valida2::Data -> Bool
valida2 (d, m, a) = let
                    bissexto::Int -> Bool
                    bissexto a
                        | mod a 400 == 0 = True
                        | mod a 4 == 0 && mod a 100 /= 0 = True
                        | otherwise = False
                    in
                    if d >= 1 && d <= 31 && (m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12) then True
                    else
                        if d >= 1 && d <= 30 && (m == 4 || m == 6 || m == 9 || m == 11) then True
                        else
                            if d >= 1 && d <= 28 && m == 2 && not (bissexto a) then True
                            else
                                if d >= 1 && d <= 29 && m == 2 && bissexto a then True
                                else
                                    False


-- -- b)
bissextos2::[Int] -> [Int]
bissextos2 xs = let 
                bissexto::Int -> Bool
                bissexto a
                    | mod a 400 == 0 = True
                    | mod a 4 == 0 && mod a 100 /= 0 = True
                    | otherwise = False
                in 
                [x | x <- xs, bissexto x]


-- c)
-- verificar se esta certo
-- type Data = (Int, Int, Int)
-- type Emprestimo = (String, String, Data, Data, String)
-- type Emprestimos = [Emprestimo]

atrasados2:: Emprestimos -> Data -> Emprestimos
atrasados2 empretimos_livros d = let 
                                verifica_emprestimo::Emprestimo -> Data -> Bool
                                verifica_emprestimo (cod_livro, cod_aluno, (d_emp, m_emp, a_emp), (d_dev, m_dev, a_dev), situacao) (d, m, a)
                                    | precede (d, m, a) (d_dev, m_dev, a_dev) = True
                                    | otherwise = False
                                precede::Data -> Data -> Bool
                                precede (d1, m1, a1) (d2, m2, a2)
                                    | (a1, m1, d1) < (a2, m2, d2) = True
                                    | otherwise = False
                                in
                                [x | x <- empretimos_livros, not (verifica_emprestimo x d)]


-- d)
fibo22::Int->Int
fibo22 n = let 
            passo::(Int,Int)->(Int,Int)
            passo (x,y)
                | x == 0 && y == 0 = (1,1)
                | otherwise = (y, x+y)
            fiboAux::Int->(Int,Int)
            fiboAux n
                | n == 1 = passo(0,0)
                | otherwise = passo(fiboAux (n-1))
            in
             fst (fiboAux n)


-- e)
fat2::Int->Int
fat2 n = let 
            prodIntervalo::Int->Int->Int
            prodIntervalo m n
                | m > n = 1
                | m == n = m
                | otherwise = m*(prodIntervalo (m+1)(n-1))*n 
            in 
            prodIntervalo 1 n


-- ex3
-- 1)
-- (\x -> 2*x + 1) 3
-- x tera o valor 3 logo teremos (2*3 + 1) resultando em 7

-- 2)
-- (\x y -> x - y) 5 7
-- x sera 5 e y sera 7 logo teremos (5 - 7) resultando em -2

-- 3)
-- (\y x -> x - y) 5 7
-- x sera 7 e y sera 5 logo teremos (7 - 5) resultando em 2

-- 4)
-- (\x y -> x - y) (\z -> z/2)
-- aplica-se x e y resultando em ((\z -> z/2) - y)
-- e nao tera mais como desenvolver
-- ou
-- aplica-se z que sera igual a (-y) resultando em (-y)/2

-- 5)
-- (\x y -> x - y) ((\z -> z/2) 6) 1
-- primeiro aplica-se z com valor 6 que resultara em (\x y -> x - y) (6/2) 1 resultando em (\x y -> x - y) 3 1
-- aplica-se x e y com valores 3 e 1, respectivamente
-- logo teremos 3 - 1 resultando em 2

-- 6)
-- (\x -> (\y -> - x y)) 9 4
-- (\x -> (\y -> x - y)) 9 4
-- aplicara primeiro x que tera valor 9 resultando em (\y -> 9 - y) 4
-- aplicando y teremos  9 - 4 que resultara em 5

-- 7) 
-- (\x -> xx) (\y -> y)
-- aplica x com o valor (\y -> y) resultando em ((\y -> y)(\y -> y))
-- nao tera mais como desenvolver


-- ex4
-- olhar imagem ex4.png


-- ex5
-- a)
-- (\x -> (\y -> y))((\z -> z)(\z -> z))(\w -> w) 5
-- x sera ((\z -> z)(\z -> z)) e y sera (\w -> w), como \x y -> y logo ficara (\w -> w) 5
-- w sera 5 e retornara 5

-- b)
-- ((\f -> (\x -> f(f x))) (\y -> (y*y))) 3
-- f sera (\y -> (y*y)) que é uma operacao que retorna o quadrado de um dado numero
-- logo ficara (\x -> (\y -> (y*y))((\y -> (y*y)) x)) 3
-- aplicando x teremos ((\y -> (y*y))((\y -> (y*y)) 3))
-- aplicando y teremos (\y -> (y*y)) 9
-- aplicando y novamente teremos 81

-- c)
-- ((\f -> (\x -> f(f x))) (\y -> (+ y y))) 5
-- ((\f -> (\x -> f(f x))) (\y -> (y + y))) 5
-- f sera (\y -> (y + y)) que é uma operacao que retorna o dobro de um dado numero
-- logo ficara (\x -> (\y -> (y + y))((\y -> (y + y)) x))) 5
-- aplicando x teremos (\y -> (y + y))((\y -> (y + y)) 5)))
-- aplicando y teremos (\y -> (y + y)) 10
-- aplicando y novamente teremos 20

-- d)
-- ((\x -> (\y -> + y x) 5) ((\y -> - y 3) 7))
-- ((\x -> (\y -> y + x) 5) ((\y -> y - 3) 7))
-- aplica x e o 1° y que serao 5 e 7, respectivamente
-- logo teremos (\y -> y + 5) (7 - 3) resultando em (\y -> y + 5) 4
-- aplicando o 2° y teremos 4 + 5 que resulta em 9

-- e)
-- (((\f -> (\x -> f(f(f x)))) (\y -> (y*y))) 2)
-- f sera (\y -> (y*y)) que é uma operacao que retorna o quadrado de um dado numero
-- logo ficara (\x -> (\y -> (y*y))((\y -> (y*y))((\y -> (y*y)) x))) 2
-- aplicando x teremos ((\y -> (y*y))((\y -> (y*y))((\y -> (y*y)) 2)))
-- aplicando y teremos ((\y -> (y*y))((\y -> (y*y)) 4))
-- aplicando y novamente teremos ((\y -> (y*y)) 16)
-- aplicando y novamente teremos 256

-- f)
-- (\x -> (\y -> + x ((\x -> - x 3) y))) 5 6
-- (\x -> (\y -> x + ((\x -> x - 3) y))) 5 6
-- aplica-se o 1° x e o y que serao 5 e 6, respectivamente
-- logo ficara 5 + ((\x -> x - 3) 6)
-- aplica-se o 2° x que recebera 6 como valor
-- ficando 5 + (6 - 3) resultando em 5 + 3
-- Resultando em 8