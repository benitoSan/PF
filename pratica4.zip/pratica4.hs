-- ex2
-- a)
ex2_a = [5, 4..1]

-- b)
ex2_b = ['a', 'c'..'e']

-- c)
ex2_c = [1, 4..16]

-- d)
ex2_d = zip [1, -2..(-11)] [1, 5..17]

-- ex3
--Perguntar pro Claudiney X..-1 da error
-- a)
intervalo::Int -> Int -> [Int]
intervalo a b = [a..b]

-- b)
intervalo_par::Int -> Int ->[Int]
intervalo_par a b = if even a then [a+2, a+4..b-1]
    else [a+1, a+3..b-1]

-- ex4
-- perguntar se é so para tirar foto ou se é pra fazer comentarios
lst1 = [x*2 | x <- [1..10], x*2 >= 12] -- retorna uma lista com o dobro do valor de numeros entre 1 e 10, mas o dobro deste valor deve ser maior ou igual a 12
lst2 = [ x | x <- [50..100], mod x 7 == 3] -- retorna uma lista com todos os valores entre 50 e 100 que tem como resto da divisao por 7 o 3
lst3 = [ x | x <- [10..20], x /= 13, x /= 15, x /= 19] -- retorna uma lista com valores entre 10 e 20 que nao sejam 13, 15 e 19
lst4=[(x,y)| x <- [1..4], y <- [x..5]] -- retorna uma lista de tuplas onde o x varia de 1 a 4 e o y sera o valor atual de x ate 5

-- ex5
quadrados::Int -> Int -> [Int]
quadrados a b = [x^2 | x <- [a..b]]

-- ex6
seleciona_impares::[Int] -> [Int]
seleciona_impares xs = [x | x <- xs, odd x]

-- ex7
tabuada::Int -> [Int]
tabuada n = [x*n | x <- [1..10]]

-- ex8
bissexto::Int -> Bool
bissexto a
    | mod a 400 == 0 = True
    | mod a 4 == 0 && mod a 100 /= 0 = True
    | otherwise = False

bissextos::[Int] -> [Int]
bissextos xs = [x | x <- xs, bissexto x]

-- ex9
-- perguntar para o Claudiney se pode assim
sublistas::[[a]] -> [a]
sublistas xs = [y | x <- xs, y <- x]
--sublistas xs = concat [x | x <-xs]

-- ex10
-- perguntar para o Claudiney se pode cheatar hard assim
type Data = (Int, Int, Int)
type Emprestimo = (String, String, Data, Data, String)
type Emprestimos = [Emprestimo]
bdEmprestimo::Emprestimos
bdEmprestimo =
 [("H123C9","BSI945",(12,9,2009),(20,09,2009),"aberto"),
 ("L433C5","BCC021",(01,9,2009),(10,09,2009),"encerrado"),
 ("M654C3","BCC008",(04,9,2009),(15,09,2009),"aberto")]

atrasados:: Emprestimos -> Data -> Emprestimos
atrasados empretimos_livros d = [x | x <- empretimos_livros, not (verifica_emprestimo x d)]

verifica_emprestimo::Emprestimo -> Data -> Bool
verifica_emprestimo (cod_livro, cod_aluno, (d_emp, m_emp, a_emp), (d_dev, m_dev, a_dev), situacao) (d, m, a)
    | precede (d, m, a) (d_dev, m_dev, a_dev) = True
    | otherwise = False

precede::Data -> Data -> Bool
precede (d1, m1, a1) (d2, m2, a2)
    | (a1, m1, d1) < (a2, m2, d2) = True
    | otherwise = False

-- ex11
uniaoNRec::[Int] -> [Int] -> [Int]
uniaoNRec xs ys = xs ++ [y | y <- ys, not(elem y xs)]
