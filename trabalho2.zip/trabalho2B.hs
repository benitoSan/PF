-- ex6
-- a)
data Exp a = Val a
    | Add (Exp a) (Exp a)
    | Sub (Exp a) (Exp a)
    | Mul (Exp a) (Exp a)
    | Div (Exp a) (Exp a)
    | Neg (Exp a)
    deriving (Show)

avalia::(Fractional a)=>Exp a -> a
avalia (Val x) = x
avalia (Add exp1 exp2) = (avalia exp1) + (avalia exp2)
avalia (Sub exp1 exp2) = (avalia exp1) - (avalia exp2)
avalia (Mul exp1 exp2) = (avalia exp1) * (avalia exp2)
avalia (Div exp1 exp2) = (avalia exp1) / (avalia exp2)
avalia (Neg x) = (avalia x)*(-1)

-- b)
expressao1 = avalia (Div (Mul (Add (Val 3) (Val 12)) (Sub (Val 15) (Val 5))) (Mul (Val 1) (Val 3)))
expressao2 = avalia (Neg (Mul (Add (Sub (Add (Val 6) (Val 8)) (Val 5)) (Val 1)) (Add (Val 2) (Div (Val 6) (Val 2)))))


-- ex7
-- a)
data Jogada = Pedra 
    | Papel 
    | Tesoura
    deriving (Eq,Show)

vence::Jogada -> Jogada -> Bool
vence Papel Pedra = True
vence Tesoura Papel = True
vence Pedra Tesoura = True
vence _ _ = False

vencedoras::[(Jogada,Jogada)] -> [Jogada]
vencedoras lista = map verifica lista

verifica::(Jogada,Jogada) -> Jogada
verifica (x,y)
    | x == y = x
    | vence x y = x
    | otherwise = y


-- ex8
-- a)
data Nebuloso = Verdadeiro | Falso | Talvez Float
    deriving (Show,Eq,Ord)

-- b)
fuzzifica::Float -> Nebuloso
fuzzifica x
    | x <= 0 = Falso
    | x >= 1 = Verdadeiro
    | otherwise = Talvez x

-- c)
pessoa_alta::Float -> Float
pessoa_alta x = (x-1.7)/0.2

verifica_alto::Float -> Nebuloso
verifica_alto x = fuzzifica (pessoa_alta x)

-- d)
carro_barato::Float -> Float
carro_barato x = (50000-x)/20000

verifica_barato::Float -> Nebuloso
verifica_barato x = fuzzifica (carro_barato x)

-- ex9
-- a)
-- ano(1°,2°,3°), nome colegio(Nacional, Olimpo e Gabarito), matricula(5letras), altura, peso
-- nome Uni(ufu,unitri,una), nome curso(Computação, Medicina, Direito e Música), matricula(8digitos), altura, idade
-- Em cada grupo, 3 alunos devem ter altura abaixo
-- de 1,70, 5 alunos devem ter altura entre 1,70 e 1,90 e 2 alunos devem ter altura acima
-- de 1,90.
data Estudante = Colegial String String String Float Float|
    Universitario String String String Float Int
    deriving (Show,Eq,Ord)

base_estudante = [(Colegial "1°" "Nacional" "ABCDE" 1.71 75.0),
                  (Colegial "2°" "Olimpo" "TJFCM" 1.76 75.5),
                  (Colegial "1°" "Gabarito" "KIIOL" 1.81 80.9),
                  (Colegial "3°" "Gabarito" "MNHJK" 1.75 75.5),
                  (Colegial "2°" "Olimpo" "QWERT" 1.81 75.0),
                  (Colegial "1°" "Nacional" "FGHJV" 1.95 100.0),
                  (Colegial "3°" "Nacional" "ASDFG" 2.01 110.0),
                  (Colegial "1°" "Nacional" "GHYTR" 1.61 58.0),
                  (Colegial "2°" "Olimpo" "CVFDE" 1.56 47.6),
                  (Colegial "3°" "Gabarito" "ASDWQ" 1.45 41.5),
                  (Universitario "UFU" "Computacao" "12345678" 1.75 23),
                  (Universitario "UNITRI" "Direito" "45678911" 1.76 21), 
                  (Universitario "UNA" "Musica" "45213652" 1.78 22), 
                  (Universitario "UNA" "Medicina" "46827931" 1.80 22), 
                  (Universitario "UNA" "Direito" "45622117" 1.72 20), 
                  (Universitario "UNITRI" "Musica" "78955246" 1.64 20), 
                  (Universitario "UNITRI" "Medicina" "77889955" 1.55 21), 
                  (Universitario "UFU" "Computacao" "78952136" 1.48 20), 
                  (Universitario "UFU" "Medicina" "45826931" 1.98 25), 
                  (Universitario "UFU" "Computacao" "11685422" 1.95 25)]

-- b)
descobre_altos::[Estudante] -> [(String, Nebuloso)]
descobre_altos l = [(pega_matricula(x),verifica_alto (pega_altura x)) | x <- l]

pega_altura::Estudante -> Float
pega_altura (Colegial _ _ _ altura _) = altura
pega_altura (Universitario _ _ _ altura _) = altura

pega_matricula::Estudante -> String
pega_matricula (Colegial _ _ matricula _ _) = matricula
pega_matricula (Universitario _ _ matricula _ _) = matricula

-- ex10
data ArvoreBinInt = Nulo |
    No Int ArvoreBinInt ArvoreBinInt
        deriving (Show,Eq,Ord)

folhas::ArvoreBinInt -> [Int]
folhas Nulo = []
folhas (No x Nulo Nulo) = [x]
folhas (No x esq dir) = (folhas esq)++(folhas dir)

somaNosinternos::ArvoreBinInt -> Int
somaNosinternos Nulo = 0
somaNosinternos (No x Nulo Nulo) = 0
somaNosinternos (No x esq dir) = (somaNosinternos esq) + (somaNosinternos dir) + x

pertence :: ArvoreBinInt -> Int -> Bool
pertence Nulo _ = False
pertence (No x esq dir) valor = pertence esq valor || x == valor || pertence dir valor

-- pertence::Int -> ArvoreBinInt -> Bool
-- pertence _ Nulo = False
-- pertence n (No x Nulo Nulo)
--     | x == n = True
--     | otherwise = False
-- pertence n (No x esq dir)
--     | x == n = True
--     | dir == Nulo = pertence n esq
--     | esq == Nulo = pertence n dir
--     | otherwise = pertence n esq || pertence n dir


