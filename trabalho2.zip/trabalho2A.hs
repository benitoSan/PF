-- listas dadas para os testes
l1=[1..2000]
l2=[2000,1999..1]
l3=l1++[0]
l4=[0]++l2
l5=l1++[0]++l2
l6=l2++[0]++l1
l7=l2++[0]++l2
x1=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
x2=[20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1]
x3=[11,12,13,14,15,16,17,18,19,20,1,2,3,4,5,6,7,8,9,10]
x4=[10,9,8,7,6,5,4,3,2,1,20,19,18,17,16,15,14,13,12,11]
x5=[11,12,13,14,15,5,4,3,2,1,16,17,18,19,20,10,9,8,7,6]
x6=[1,12,3,14,5,15,4,13,2,11,6,17,8,19,20,10,9,18,7,16]
x7 = [20,8,2,11,13,3,7,18,14,4,16,10,15,1,9,17,19,12,5,6]

-- ex1
-- Bubble simples com contador
bolha::(Ord a) => [a] -> ([a],Int)
bolha [] = ([],0)
bolha l = bolhaOrd (l,0) (length l)


bolhaOrd::(Ord a) => ([a],Int) -> Int -> ([a],Int)
bolhaOrd (l,numero_trocas) 0 = (l,numero_trocas)
bolhaOrd (l,numero_trocas) n = bolhaOrd (l1,(numero_trocas+trocas)) (n-1)
    where
        (l1,trocas) = troca l

troca::(Ord a) => [a] -> ([a],Int)
troca [x] = ([x],0)
troca (x:y:xs)
    | x <= y = (x:ws,numero_trocas1)
    | otherwise = (y:zs,(numero_trocas2+1))
    where
        (ws,numero_trocas1) = troca (y:xs)
        (zs,numero_trocas2) = troca (x:xs)


-- Varicao 1: Com parada e contador
bolhap::(Ord a) => [a] -> ([a],Int)
bolhap [] = ([],0)
bolhap l = bolhaOrdp (l,0) (length l)


bolhaOrdp::(Ord a) => ([a],Int) -> Int -> ([a],Int)
bolhaOrdp (l,numero_trocas) 0 = (l,numero_trocas)
bolhaOrdp (l,numero_trocas) n = if trocas == 0 then bolhaOrdp (l1,(numero_trocas+trocas)) 0
    else bolhaOrdp (l1,(numero_trocas+trocas)) (n-1)
    where
        (l1,trocas) = trocap l

trocap::(Ord a) => [a] -> ([a],Int)
trocap [x] = ([x],0)
trocap (x:y:xs)
    | x <= y = (x:ws,numero_trocas1)
    | otherwise = (y:zs,(numero_trocas2+1))
    where
        (ws,numero_trocas1) = trocap (y:xs)
        (zs,numero_trocas2) = trocap (x:xs)


-- Variacao 2 Com contador, parada e diminui lista
bolhapdl::(Ord a) => [a] -> ([a],Int)
bolhapdl [] = ([],0)
bolhapdl l = bolhaOrdpdl (l,0) (length l) []

-- l, l1 -> lista que diminui
-- lista -> lista ordenada
bolhaOrdpdl::(Ord a) => ([a],Int) -> Int -> [a] -> ([a],Int)
bolhaOrdpdl (_,numero_trocas) 0 lista = (lista,numero_trocas)
bolhaOrdpdl (l,numero_trocas) n lista = if trocas == 0 then bolhaOrdpdl (l1,numero_trocas) 0 (l++lista)
    else bolhaOrdpdl (l1,(numero_trocas+trocas)) (n-1) (lista_aux++lista)
    where
        (l1,trocas,lista_aux) = trocapdl l

trocapdl::(Ord a) => [a] -> ([a],Int,[a])
trocapdl [x] = ([],0,[x])
trocapdl (x:y:xs)
    | x <= y = (x:ws,numero_trocas1,lista_aux1)
    | otherwise = (y:zs,(numero_trocas2+1),lista_aux2)
    where
        (ws,numero_trocas1,lista_aux1) = trocapdl (y:xs)
        (zs,numero_trocas2,lista_aux2) = trocapdl (x:xs)



-- ex2
-- Selection simples com contador
selecao::(Ord a) => [a] -> ([a],Int)
selecao [] = ([],0)
selecao l = ([x]++lista,n+trocas)
    where 
        (lista,n) = selecao (remover x l)
        (x,trocas) = minimo l


remover::(Ord a) => a -> [a] -> [a]
remover x [] = []
remover x (y:ys)
    | x == y = ys
    | otherwise = y:remover x ys


minimo::(Ord a) => [a] -> (a,Int)
minimo [x] = (x,0)
minimo (x:y:xs) 
    | x <= y = (ws,trocas1)
    | otherwise = (zs,trocas2+1)
    where
        (ws,trocas1) = minimo (x:xs)
        (zs,trocas2) = minimo (y:xs)


-- Varicao 1 Selection com contador e elimina o menor elemento quando achar
selecaorm::(Ord a) => [a] -> ([a],Int)
selecaorm [] = ([],0)
selecaorm l = ([x]++lista,n+trocas)
    where 
        (lista,n) = selecaorm lista1
        (lista1,trocas,x) = remove_minimo l


remove_minimo::(Ord a) => [a] -> ([a],Int,a)
remove_minimo [x] = ([],0,x)
remove_minimo (x:y:xs)
    | x <= y  = (y:ws,trocas1,a)
    | otherwise = (x:zs, trocas2+1,b)
    where
        (ws,trocas1,a) = remove_minimo (x:xs) 
        (zs,trocas2,b) = remove_minimo (y:xs)


-- Variacao 2 Selection com contador e foldr
selecaofr::(Ord a) => [a] -> ([a],Int)
selecaofr [] = ([],0)
selecaofr l = (head(x):lista,n+trocas)
    where 
        (lista,n) = selecaofr (foldr remover l x)
        (x,trocas) = minimofr l


removerfr::(Ord a) => a -> [a] -> [a]
removerfr x [] = []
removerfr x (y:ys)
    | x == y = ys
    | otherwise = y:remover x ys


minimofr::(Ord a) => [a] -> ([a],Int)
minimofr [x] = ([x],0)
minimofr (x:y:xs)
    | x <= y = (ws,trocas1)
    | otherwise = (zs,trocas2+1)
    where
        (ws,trocas1) = minimofr (x:xs)
        (zs,trocas2) = minimofr (y:xs)



-- ex3
-- Insertion simples com contador
insercao::(Ord a) => [a] -> ([a],Int)
insercao [] = ([],0)
insercao (x:xs) = (lista,n+trocas)
    where 
        (lista,trocas) = insereOrd x l
        (l,n) = insercao xs

insereOrd::(Ord a) => a -> [a] -> ([a],Int)
insereOrd x [] = ([x],0)
insereOrd y (x:xs)
    | x < y = (x:ys, trocas1+1)
    | otherwise = ((y:x:xs),trocas1+1)
    where 
        (ys,trocas1) = insereOrd y xs


-- Variacao 1 Com contador e foldr
insercaofr::(Ord a) => [a] -> ([a],Int)
insercaofr [] = ([],0)
insercaofr l = (lista,trocas)
    where 
        (lista,trocas) = foldr insereOrdfr ([],0) l

insereOrdfr::(Ord a) => a -> ([a],Int) -> ([a],Int)
insereOrdfr x ([],0) = ([x],0)
insereOrdfr y ((x:xs),n)
    | x < y = (x:ys, n+1)
    | otherwise = ((y:x:xs),n+1)
    where 
        (ys,n) = insereOrdfr y (xs,0)



-- ex4
-- Quick com contador
quicksort::(Ord a) => [a]->([a],Int)
quicksort [] = ([],0)
quicksort (x:xs) = (val_menores ++ [x] ++ val_maiores,numero_trocas1+numero_trocas2+trocas1+trocas2)
 where
    trocas1 = length(val_menores)
    trocas2 = length(val_maiores)
    (val_menores,numero_trocas2) = quicksort (filter (x>=) xs)
    (val_maiores,numero_trocas1) = quicksort (filter (x<) xs)


-- Varicao 1 Quick com contador e com funcao divide
quicksortd::(Ord a) => [a]->([a],Int)
quicksortd [] = ([],0)
quicksortd (x:xs) = (l1 ++ [x] ++ l2,numero_trocas+trocas1+trocas2)
 where
    (l1,trocas1) =  quicksortd val_menores
    (l2,trocas2) = quicksortd val_maiores
    (val_menores,val_maiores,numero_trocas) = divide x xs

divide::(Ord a) => a->[a]->([a],[a],Int)
divide _ [] = ([],[],0)
divide y (x:xs)
 | x < y = (x:ws,zs,n+1)
 | x >= y = (ws,x:zs,n+1)
 where 
    (ws,zs,n) = divide y xs


-- Variacao 2 Quick com contador com divide e com selecao de pivo
quicksortp::(Ord a) => [a]->([a],Int)
quicksortp [] = ([],0)
quicksortp l = (l1 ++ [pivo] ++ l2,numero_trocas+trocas1+trocas2)
 where
    (l1,trocas1) =  quicksortp val_menores
    (l2,trocas2) = quicksortp val_maiores
    (val_menores,val_maiores,numero_trocas) = dividep pivo (remover_pivo pivo l)
    pivo = selecao_pivo a b c
    (a,b,c) = verifica_tres l

dividep::(Ord a) => a->[a]->([a],[a],Int)
dividep _ [] = ([],[],0)
dividep y (x:xs)
 | x < y = (x:ws,zs,n+1)
 | x >= y = (ws,x:zs,n+1)
 where 
    (ws,zs,n) = dividep y xs

selecao_pivo::(Ord a)=> a -> a -> a -> a
selecao_pivo x y z
    | (x > y && x < z) || (x < y && x > z) = x
    | (y >= x && y < z) || (y <= x && y > z) = y
    | otherwise = z

verifica_tres::(Ord a)=> [a] -> (a,a,a)
verifica_tres [] = undefined
verifica_tres l = if length(l) < 3 then (head(l),head(l),head(l))
    else pega_tres l

pega_tres::(Ord a)=> [a] -> (a,a,a)
pega_tres (x:y:z:xs) = (x,y,z)

remover_pivo::(Ord a)=> a -> [a] -> [a]
remover_pivo _ [] = []
remover_pivo x (y:ys)
    | x == y = ys
    | otherwise = y:(remover_pivo x ys)



-- ex5
-- Merge com contador
merge::(Ord a) => [a] -> [a] -> Int -> ([a],Int)
merge xs [] n = (xs,0)
merge [] ys n = (ys,0)
merge (x:xs) (y:ys) n
    | x <= y    = (x:ws,trocas1+1)
    | otherwise = (y:zs,trocas2+1)
        where
            (ws,trocas1) = merge xs (y:ys) n
            (zs,trocas2) = merge (x:xs) ys n

firstHalf  xs = take (div (length xs) 2) xs
secondHalf xs = drop (div (length xs) 2) xs

msort::(Ord a) => [a] -> ([a],Int)
msort [] = ([],0)
msort [x] = ([x],0)
msort l = msort_aux (l,0)

msort_aux::(Ord a) => ([a],Int) -> ([a],Int)
msort_aux ([],0) = ([],0)
msort_aux ([x],0) = ([x],0)
msort_aux (lista,numero_trocas) = merge lista1 lista2 (n1+n2)
    where
        (lista1,n1) = msort_aux (metade1,numero_trocas)
        (lista2,n2) = msort_aux (metade2,numero_trocas)
        metade1 = firstHalf lista
        metade2 = secondHalf lista