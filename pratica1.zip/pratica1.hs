--ex2
dobro n = 2*n

--ex3
quad n = dobro n + dobro n 

--ex4
descobre_hipotenusa x y = sqrt(x**2 + y**2)

--ex5
dist_pontos a b = abs(a - b)